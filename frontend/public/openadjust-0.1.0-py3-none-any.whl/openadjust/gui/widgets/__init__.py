"""
Reusable GUI widgets.
"""
