"""
Graphical User Interface module.
"""
