"""
Utility functions.
"""
